// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Crawl 500 pages, respect robots");
  std::fflush(stdout);
  return lionss_run_workload("seocrawl");
}
