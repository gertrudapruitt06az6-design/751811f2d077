// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Partition and heal 50 times"); }
int main(){
  announce();
  return lionss_run_workload("raftPartition");
}
