// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Single-flight under 2k rps\n", stdout);
  return lionss_run_workload("cache_stampede");
}
