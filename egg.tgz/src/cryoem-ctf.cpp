// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("CTF estimation per micrograph\n", stdout);
  return lionss_run_workload("cryoem-ctf");
}
