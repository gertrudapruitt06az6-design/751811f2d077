// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fix one-way tag conflicts"); }
int main(){
  announce();
  return lionss_run_workload("kbn_osm_fix");
}
