// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Produce bsdiff delta\n", stdout);
  return lionss_run_workload("otaDelta");
}
