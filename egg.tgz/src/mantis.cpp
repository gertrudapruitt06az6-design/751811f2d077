// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Train 16 KB dictionary"); }
int main(){
  announce();
  return lionss_run_workload("mantis");
}
