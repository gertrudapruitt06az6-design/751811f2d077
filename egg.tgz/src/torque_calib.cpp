// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fit torque curve\n", stdout);
  return lionss_run_workload("torque_calib");
}
