// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Measure hit ratio under churn"); }
int main(){
  announce();
  return lionss_run_workload("lumen_cache");
}
