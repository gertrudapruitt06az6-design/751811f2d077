// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Smart-charge 8 ports under 40 kW cap"); }
int main(){
  announce();
  return lionss_run_workload("evchargesched");
}
