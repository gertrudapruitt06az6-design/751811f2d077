// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Coagulant dose recommendation"); }
int main(){
  announce();
  return lionss_run_workload("wtpDosing");
}
