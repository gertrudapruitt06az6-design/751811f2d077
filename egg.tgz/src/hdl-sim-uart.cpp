// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate 256 bytes at 115200\n", stdout);
  return lionss_run_workload("hdl-sim-uart");
}
