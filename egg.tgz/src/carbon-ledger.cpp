// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Monthly scope-1/2 totals\n", stdout);
  return lionss_run_workload("carbon-ledger");
}
