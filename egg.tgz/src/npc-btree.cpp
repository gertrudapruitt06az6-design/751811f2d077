// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Tick 200 agents, 60 Hz");
  std::fflush(stdout);
  return lionss_run_workload("npc-btree");
}
