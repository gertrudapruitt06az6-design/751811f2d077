# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(raw-develop src/raw-develop.cpp)
set_property(TARGET raw-develop PROPERTY CXX_STANDARD 11)
target_link_libraries(raw-develop lionss pthread)

add_executable(seocrawl src/seocrawl.cpp)
set_property(TARGET seocrawl PROPERTY CXX_STANDARD 11)
target_link_libraries(seocrawl lionss pthread)

add_executable(evchargesched src/evchargesched.cpp)
set_property(TARGET evchargesched PROPERTY CXX_STANDARD 11)
target_link_libraries(evchargesched lionss pthread)

add_executable(moth src/moth.cpp)
set_property(TARGET moth PROPERTY CXX_STANDARD 11)
target_link_libraries(moth lionss pthread)

add_executable(coupon-stack src/coupon-stack.cpp)
set_property(TARGET coupon-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(coupon-stack lionss pthread)

add_executable(kbn_osm_fix src/kbn_osm_fix.cpp)
set_property(TARGET kbn_osm_fix PROPERTY CXX_STANDARD 11)
target_link_libraries(kbn_osm_fix lionss pthread)

add_executable(torque_calib src/torque_calib.cpp)
set_property(TARGET torque_calib PROPERTY CXX_STANDARD 11)
target_link_libraries(torque_calib lionss pthread)

add_executable(ember_v2 src/ember_v2.cpp)
set_property(TARGET ember_v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember_v2 lionss pthread)

add_executable(mantis src/mantis.cpp)
set_property(TARGET mantis PROPERTY CXX_STANDARD 11)
target_link_libraries(mantis lionss pthread)

add_executable(cryoem-ctf src/cryoem-ctf.cpp)
set_property(TARGET cryoem-ctf PROPERTY CXX_STANDARD 11)
target_link_libraries(cryoem-ctf lionss pthread)

add_executable(hiveMonitor src/hiveMonitor.cpp)
set_property(TARGET hiveMonitor PROPERTY CXX_STANDARD 11)
target_link_libraries(hiveMonitor lionss pthread)

add_executable(etl-weekly-crm src/etl-weekly-crm.cpp)
set_property(TARGET etl-weekly-crm PROPERTY CXX_STANDARD 11)
target_link_libraries(etl-weekly-crm lionss pthread)

add_executable(cache_stampede src/cache_stampede.cpp)
set_property(TARGET cache_stampede PROPERTY CXX_STANDARD 11)
target_link_libraries(cache_stampede lionss pthread)

add_executable(vlan_planner src/vlan_planner.cpp)
set_property(TARGET vlan_planner PROPERTY CXX_STANDARD 11)
target_link_libraries(vlan_planner lionss pthread)

add_executable(brindle src/brindle.cpp)
set_property(TARGET brindle PROPERTY CXX_STANDARD 11)
target_link_libraries(brindle lionss pthread)

add_executable(otaDelta src/otaDelta.cpp)
set_property(TARGET otaDelta PROPERTY CXX_STANDARD 11)
target_link_libraries(otaDelta lionss pthread)

add_executable(tex-thesis src/tex-thesis.cpp)
set_property(TARGET tex-thesis PROPERTY CXX_STANDARD 11)
target_link_libraries(tex-thesis lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(hdl-sim-uart src/hdl-sim-uart.cpp)
set_property(TARGET hdl-sim-uart PROPERTY CXX_STANDARD 11)
target_link_libraries(hdl-sim-uart lionss pthread)

add_executable(sla-report src/sla-report.cpp)
set_property(TARGET sla-report PROPERTY CXX_STANDARD 11)
target_link_libraries(sla-report lionss pthread)

add_executable(raftPartition src/raftPartition.cpp)
set_property(TARGET raftPartition PROPERTY CXX_STANDARD 11)
target_link_libraries(raftPartition lionss pthread)

add_executable(carbon-ledger src/carbon-ledger.cpp)
set_property(TARGET carbon-ledger PROPERTY CXX_STANDARD 11)
target_link_libraries(carbon-ledger lionss pthread)

add_executable(npc-btree src/npc-btree.cpp)
set_property(TARGET npc-btree PROPERTY CXX_STANDARD 11)
target_link_libraries(npc-btree lionss pthread)

add_executable(crabgraph src/crabgraph.cpp)
set_property(TARGET crabgraph PROPERTY CXX_STANDARD 11)
target_link_libraries(crabgraph lionss pthread)

add_executable(chalk src/chalk.cpp)
set_property(TARGET chalk PROPERTY CXX_STANDARD 11)
target_link_libraries(chalk lionss pthread)

add_executable(BedManager src/BedManager.cpp)
set_property(TARGET BedManager PROPERTY CXX_STANDARD 11)
target_link_libraries(BedManager lionss pthread)

add_executable(wtpDosing src/wtpDosing.cpp)
set_property(TARGET wtpDosing PROPERTY CXX_STANDARD 11)
target_link_libraries(wtpDosing lionss pthread)

add_executable(price-elasticity src/price-elasticity.cpp)
set_property(TARGET price-elasticity PROPERTY CXX_STANDARD 11)
target_link_libraries(price-elasticity lionss pthread)

add_executable(abtest-reader src/abtest-reader.cpp)
set_property(TARGET abtest-reader PROPERTY CXX_STANDARD 11)
target_link_libraries(abtest-reader lionss pthread)

add_executable(lumen_cache src/lumen_cache.cpp)
set_property(TARGET lumen_cache PROPERTY CXX_STANDARD 11)
target_link_libraries(lumen_cache lionss pthread)

